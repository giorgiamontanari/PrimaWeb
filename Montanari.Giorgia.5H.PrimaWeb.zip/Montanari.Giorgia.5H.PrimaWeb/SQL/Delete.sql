DELETE 
FROM Prenotazioni
WHERE PrenotazioneId=13
OR PrenotazioneId=12;

SELECT *
FROM Prenotazioni;